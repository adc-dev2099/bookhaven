/* ═══════════════════════════════════════════════════
   BOOKHAVEN — SHARED JS
   api.js — config, auth helpers, api layer, utilities
═══════════════════════════════════════════════════ */

const API_BASE = 'http://localhost:8080';

// ─── TOKEN STORAGE ────────────────────────────────
const Auth = {
  getToken()    { return localStorage.getItem('bh_token'); },
  getUser()     { return localStorage.getItem('bh_user'); },
  getRole()     { return localStorage.getItem('bh_role'); },
  setSession(token, username, role) {
    localStorage.setItem('bh_token', token);
    localStorage.setItem('bh_user', username);
    localStorage.setItem('bh_role', role || 'user');
  },
  clear() {
    localStorage.removeItem('bh_token');
    localStorage.removeItem('bh_user');
    localStorage.removeItem('bh_role');
  },
  isLoggedIn()  { return !!this.getToken(); },
  isAdmin()     { return this.getRole() === 'admin'; },
  headers(json = true) {
    const h = {};
    if (json) h['Content-Type'] = 'application/json';
    if (this.getToken()) h['Authorization'] = `Bearer ${this.getToken()}`;
    return h;
  }
};

// ─── HTTP HELPERS ─────────────────────────────────
async function apiFetch(path, options = {}) {
  const res = await fetch(API_BASE + path, {
    headers: Auth.headers(),
    ...options,
  });
  if (res.status === 401) {
    Auth.clear();
    window.location.href = 'login.html';
    return null;
  }
  const ct = res.headers.get('content-type') || '';
  const body = ct.includes('application/json') ? await res.json() : await res.text();
  if (!res.ok) {
    const msg = (body && body.message) ? body.message : `Error ${res.status}`;
    throw new Error(msg);
  }
  return body;
}

async function apiPost(path, data) {
  return apiFetch(path, { method: 'POST', body: JSON.stringify(data) });
}
async function apiPut(path, data) {
  return apiFetch(path, { method: 'PUT', body: JSON.stringify(data) });
}
async function apiPatch(path, data) {
  return apiFetch(path, { method: 'PATCH', body: data !== undefined ? JSON.stringify(data) : undefined });
}
async function apiDelete(path) {
  return apiFetch(path, { method: 'DELETE' });
}

// ─── TOAST ────────────────────────────────────────
function toast(message, type = 'info') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }
  const icons = { info: 'ℹ️', success: '✅', error: '❌', warning: '⚠️' };
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `<span class="toast-icon">${icons[type] || 'ℹ️'}</span><span>${escHtml(message)}</span>`;
  container.appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transform = 'translateX(30px)'; el.style.transition = '0.3s'; setTimeout(() => el.remove(), 300); }, 3000);
}

// ─── CONFIRM DIALOG ───────────────────────────────
let _confirmResolve = null;
function showConfirm(title, message) {
  return new Promise(resolve => {
    _confirmResolve = resolve;
    const overlay = document.getElementById('confirm-overlay');
    if (!overlay) { resolve(window.confirm(message)); return; }
    overlay.querySelector('.confirm-title').textContent = title;
    overlay.querySelector('.confirm-msg').textContent = message;
    overlay.classList.add('open');
    _confirmResolve = resolve;
  });
}
function confirmYes() {
  document.getElementById('confirm-overlay').classList.remove('open');
  if (_confirmResolve) { _confirmResolve(true); _confirmResolve = null; }
}
function confirmNo() {
  document.getElementById('confirm-overlay').classList.remove('open');
  if (_confirmResolve) { _confirmResolve(false); _confirmResolve = null; }
}

// ─── UTILITY ──────────────────────────────────────
function escHtml(s) {
  return String(s ?? '')
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function formatPrice(n) {
  return '₱' + Number(n || 0).toFixed(2);
}

function formatDate(dt) {
  if (!dt) return '—';
  return new Date(dt).toLocaleDateString('en-PH', { year: 'numeric', month: 'short', day: 'numeric' });
}

function formatDateTime(dt) {
  if (!dt) return '—';
  return new Date(dt).toLocaleString('en-PH', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function debounce(fn, ms = 350) {
  let t; return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

// ─── NAV RENDERING ────────────────────────────────
function renderNav(activePage) {
  const isLoggedIn = Auth.isLoggedIn();
  const isAdmin    = Auth.isAdmin();
  const user       = Auth.getUser();

  const navEl = document.getElementById('main-nav');
  if (!navEl) return;

  navEl.innerHTML = `
    <a class="nav-brand" href="index.html">Book<span>Haven</span></a>
    <div class="nav-links">
      <a class="nav-link ${activePage === 'catalog' ? 'active' : ''}" href="index.html">Catalog</a>
      ${isLoggedIn ? `<a class="nav-link ${activePage === 'cart' ? 'active' : ''}" href="cart.html">Cart</a>` : ''}
      ${isLoggedIn ? `<a class="nav-link ${activePage === 'orders' ? 'active' : ''}" href="orders.html">My Orders</a>` : ''}
      ${isAdmin    ? `<a class="nav-link ${activePage === 'admin' ? 'active' : ''}" href="admin.html">Admin</a>` : ''}
    </div>
    <div class="nav-right">
      ${isLoggedIn ? `
        <span class="nav-user">👤 ${escHtml(user)}</span>
        <button class="btn-nav-signout" onclick="doLogout()">Sign Out</button>
        <button class="btn-cart" onclick="window.location.href='cart.html'">
          🛒 Cart <span class="cart-badge hidden" id="cart-badge">0</span>
        </button>
      ` : `
        <a class="btn btn-secondary btn-sm" href="login.html">Sign In</a>
        <a class="btn btn-primary btn-sm" href="login.html">Register</a>
      `}
    </div>`;

  if (isLoggedIn) loadCartBadge();
}

async function loadCartBadge() {
  try {
    const data = await apiFetch('/api/cart');
    const count = (data?.items || []).reduce((s, i) => s + (i.quantity || 0), 0);
    const badge = document.getElementById('cart-badge');
    if (badge) {
      badge.textContent = count;
      badge.classList.toggle('hidden', count === 0);
    }
  } catch(e) {}
}

function doLogout() {
  Auth.clear();
  window.location.href = 'index.html';
}

// ─── CONFIRM HTML (injected if missing) ───────────
function ensureConfirmDialog() {
  if (document.getElementById('confirm-overlay')) return;
  const div = document.createElement('div');
  div.id = 'confirm-overlay';
  div.innerHTML = `
    <div class="confirm-box">
      <h3 class="confirm-title">Confirm Action</h3>
      <p class="confirm-msg">Are you sure?</p>
      <div class="actions">
        <button class="btn btn-ghost" onclick="confirmNo()">Cancel</button>
        <button class="btn btn-danger" onclick="confirmYes()">Confirm</button>
      </div>
    </div>`;
  document.body.appendChild(div);
}